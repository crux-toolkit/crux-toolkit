#!/bin/sh
./tide-index --fasta=worm.fasta --enzyme=trypsin --digestion=full-digest --mods_spec=C+57.02146
