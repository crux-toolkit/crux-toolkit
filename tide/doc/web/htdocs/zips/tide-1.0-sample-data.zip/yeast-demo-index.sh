#!/bin/sh
./tide-index --fasta=yeast.fasta --enzyme=trypsin --digestion=full-digest --mods_spec=C+57.02146
