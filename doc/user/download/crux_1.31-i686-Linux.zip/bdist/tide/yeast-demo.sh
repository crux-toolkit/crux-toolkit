#!/bin/sh
./tide-index --fasta=yeast.fasta --enzyme=trypsin --digestion=full-digest
./tide-import-spectra --in=yeast-02-10000.ms2 -out=yeast-02-10000.spectrumrecords
./tide-search --peptides=yeast.fasta.pepix --proteins=yeast.fasta.protix \
              --spectra=yeast-02-10000.spectrumrecords  > yeast.results
