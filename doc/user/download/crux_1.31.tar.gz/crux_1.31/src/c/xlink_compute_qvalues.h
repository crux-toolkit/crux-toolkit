#ifndef XLINK_COMPUTE_QVALUES_H
#define XLINK_COMPUTE_QVALUES_H


int xlink_compute_qvalues();


#endif
