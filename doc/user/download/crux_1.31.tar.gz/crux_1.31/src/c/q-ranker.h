#ifndef QRANKER_CMD_H
#define QRANKER_CMD_H
/**
 * \file q-ranker.h
 */
/*
 * AUTHOR: Barbara Frewen
 * CREATE DATE: November 25, 2008
 * DESCRIPTION: Header file for crux q-ranker command. 
 *
 * $Revision: 1.1.2.3 $
 */

int qranker_main(int argc, char** argv);

#endif //QRANKER_CMD_H

