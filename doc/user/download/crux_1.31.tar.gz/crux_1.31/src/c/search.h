/**
 * \file search.h
 * AUTHOR: Barbara Frewen
 * CREATE DATE: November 24, 2008
 * \brief Header file for the search-for-matches crux command
 */
#ifndef SEARCH_H
#define SEARCH_H

int search_main(int argc, char** argv);

#endif // SEARCH_H
