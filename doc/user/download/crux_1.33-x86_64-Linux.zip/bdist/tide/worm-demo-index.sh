#!/bin/sh
./tide-index --fasta=worm.fasta --enzyme=trypsin --digestion=full-digest
