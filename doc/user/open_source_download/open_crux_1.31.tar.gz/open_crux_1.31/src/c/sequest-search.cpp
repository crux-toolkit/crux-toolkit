/**
 * \file sequest-search.cpp
 * AUTHOR: Barbara Frewen
 * CREATE DATE: Oct 2, 2009
 * PROJECT: crux
 * \brief The crux search routine that emulates SEQUEST.
 *
 * Scores all candidate peptides with Sp, deletes all but the 500
 * top-scoring candidates, scores remaining 500 with xcorr, sorts
 * results by xcorr and returns the top 5 plus the match with the best
 * Sp score.  Writes results to .sqt, .txt, and .csm files.  Does not
 * compute p-values.
 */

#include "sequest-search.h"

// Private functions, commented below at definition
void print_matches(
  OutputFiles& output_files,       
  MATCH_COLLECTION_T* target_psms, 
  vector<MATCH_COLLECTION_T*>& decoy_psms,
  SPECTRUM_T* spectrum,             
  BOOLEAN_T combine_target_decoy,
  int num_decoy_files
                   );

/**
 * \brief The starting point for the crux sequest-search command.
 *
 * After parsing command line and opening input and output files,
 * iterates over every spectrum at each charge state.  Generates
 * matches for each and prints.  Matches to decoy spectra can also be
 * generated.  If num-decoys-per-target is n, there are n decoy match
 * collections which may be merged for printing.  
 * If the user gave the command line
 *
 * crux sequest-search [options] ms2file proteins
 * 
 * then this is passed everything after the 'crux' token
 */
int sequest_search_main(int argc, char **argv){
  (void) argc;
  (void) argv;
  fputs(
    "You are using the open source version of Crux. Due to intellectual\n"
    "property issues, we are unable to provide database search functionality\n"
    "in this version. To obtain a licence for the full functional version of\n"
    "Crux that includes the database search tools, please visit the following URL:\n"
    "\nhttp://depts.washington.edu/ventures/UW_Technology/Express_Licenses/crux.php\n",
    stderr
  );
  return 1;
}




/* Private function definitions */

/**
 * \brief Pring the target and decoy match collections to their
 * respective target and decoy files.
 *
 * Three possibilities: 1. combine the target and all decoy
 * collections and print to target file.  2. print targets to target
 * file and combine all decoys and print to one decoy file.  3. print
 * each collection to a separate file.
 * Possible side effectos: Collections may be merged and re-ranked.
 */
void print_matches(
  OutputFiles& output_files,       ///< files to print to
  MATCH_COLLECTION_T* target_psms, ///< target psms to print
  vector<MATCH_COLLECTION_T*>& decoy_psms,///< decoy psms to print
  SPECTRUM_T* spectrum,            ///< all matches are to this spec
  BOOLEAN_T combine_target_decoy,  ///< merge targets and decoys?
  int num_decoy_files              ///< merge decoys?
){ 

  if( combine_target_decoy ){

    // merge all collections
    MATCH_COLLECTION_T* all_psms = target_psms;
    for(size_t decoy_idx = 0; decoy_idx < decoy_psms.size(); decoy_idx++){
      merge_match_collections(decoy_psms.at(decoy_idx), all_psms);
    }

    // sort and rank
    populate_match_rank_match_collection(all_psms, SP);
    save_top_sp_match(all_psms);
    populate_match_rank_match_collection(all_psms, XCORR);
    output_files.writeMatches(all_psms, // target matches
                              NULL,     // decoy matches
                              0,        // num decoys
                              XCORR,    // use XCORR rank for cutoff
                              spectrum); 


  }else{ // targets and decoys in separate files

    if( num_decoy_files == 1 ){ // combine decoys

      // merge decoys
      MATCH_COLLECTION_T* merged_decoy_psms = decoy_psms.at(0);
      for(size_t decoy_idx = 1; decoy_idx < decoy_psms.size(); decoy_idx++){
        merge_match_collections(decoy_psms.at(decoy_idx),
                                merged_decoy_psms);
      }
      
      // sort and rank
      populate_match_rank_match_collection(merged_decoy_psms, SP);
      save_top_sp_match(merged_decoy_psms);
      populate_match_rank_match_collection(merged_decoy_psms, XCORR);

      output_files.writeMatches(target_psms, &merged_decoy_psms, 
                                1, // num decoys
                                XCORR, spectrum);
      
    }else{   // write targets and decoys to separate files
      // TODO write a version of OutputFiles::writeMatches that takes
      // a vector of decoy match collections
      int num_decoys = decoy_psms.size();
      MATCH_COLLECTION_T** decoy_psm_array = 
        (MATCH_COLLECTION_T**)mycalloc(num_decoys, sizeof(MATCH_COLLECTION_T*));
      for(int decoy_idx = 0; decoy_idx < num_decoys; decoy_idx++){
        decoy_psm_array[decoy_idx] = decoy_psms.at(decoy_idx);
      }

      output_files.writeMatches(target_psms, decoy_psm_array, num_decoys, 
                                XCORR, spectrum);
    }
  }


}








/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 2
 * End:
 */
