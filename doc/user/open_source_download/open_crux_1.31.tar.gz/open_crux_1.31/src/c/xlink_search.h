#ifndef XLINK_SEARCH_CMD_H
#define XLINK_SEARCH_CMD_H

/**
 * \file xlink_search.h
 * AUTHOR: Sean McIlwain
 * CREATE DATE: November 19, 2009
 * \brief Header file for crux search-for-xlinks command. 
 */

int xlink_search_main(int argc, char** argv);

#endif //PERCOLATOR_CMD_H

