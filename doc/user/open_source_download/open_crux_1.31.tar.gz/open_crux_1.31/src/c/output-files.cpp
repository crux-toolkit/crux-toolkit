/**
 * \file output-files.cpp
 * AUTHOR: Barbara Frewen
 * CREATE DATE: Aug 24, 2009
 * PROJECT: crux
 * \brief A class description for handling all the various
 * output files, excluding parameter and log files.
 *
 * The filenames, locations and overwrite status are taken from
 * parameter.c.
 */

#include "output-files.h"
using namespace std;

/**
 * Default constructor for OutputFiles.  Opens all of the needed
 * files, naming them based on the values of the parameters output-dir
 * and fileroot and on the name given (search, percolator, etc.).
 * Requires that the output directory already exist. 
 */
OutputFiles::OutputFiles(COMMAND_T program_name)
: matches_per_spec_(get_int_parameter("top-match"))
{

  tab_file_array_ = NULL;
  sqt_file_array_ = NULL;
  feature_file_ = NULL;

  // parameters for all three file types
  BOOLEAN_T overwrite = get_boolean_parameter("overwrite");
  const char* output_directory = get_string_parameter_pointer("output-dir");
  const char* fileroot = get_string_parameter_pointer("fileroot");
  if( strcmp(fileroot, "__NULL_STR") == 0 ){
    fileroot = NULL;
  }

  int num_decoy_files = get_int_parameter("num-decoy-files");
  num_files_ = num_decoy_files + 1; // plus target file

  // TODO (BF oct-21-09): consider moving this logic to parameter.c
  if( program_name != SEARCH_COMMAND && program_name != SEQUEST_COMMAND ){
    num_files_ = 1;
  }

  carp(CARP_DEBUG, 
       "OutputFiles is opening %d files (%d decoys) in '%s' with root '%s'."
       " Overwrite: %d.", 
       num_files_, num_decoy_files, output_directory, fileroot, overwrite);

  // all operations create tab files
  createFiles(&tab_file_array_, 
              output_directory, 
              fileroot, 
              program_name, 
              "txt", 
              overwrite); 

  // only sequest creates sqt files
  if( program_name == SEQUEST_COMMAND ){
    createFiles(&sqt_file_array_, 
                 output_directory, 
                 fileroot, 
                 program_name, 
                 "sqt", 
                 overwrite);
  }

  // only percolator and q-ranker create feature files
  if( (program_name == PERCOLATOR_COMMAND 
       || program_name == QRANKER_COMMAND)
      && get_boolean_parameter("feature-file") ){
    createFile(&feature_file_, 
               output_directory, 
               fileroot, 
               program_name, 
               "features.txt", 
               overwrite);
  }
}

OutputFiles::~OutputFiles(){
  for(int file_idx = 0; file_idx < num_files_; file_idx ++){
    if( tab_file_array_ ){ fclose(tab_file_array_[file_idx]); }
    if( sqt_file_array_ ){ fclose(sqt_file_array_[file_idx]); }
  }
  if( feature_file_ ){ fclose(feature_file_); }

  delete tab_file_array_;
  delete sqt_file_array_;
}

/**
 * A private function for generating target and decoy files named
 * according to the given arguments.
 *
 * New files are returned via the file_array_ptr argument.  When
 * num_files > 1, exactly one target file is created and the remaining
 * are decoys.  Files are named 
 * "output-dir/fileroot.command_name.target|decoy[n].extension".
 * Requires that the output-dir already exist and have write
 * permissions. 
 * \returns TRUE if num_files new files are created, else FALSE.
 */
BOOLEAN_T OutputFiles::createFiles(FILE*** file_array_ptr,
                                   const char* output_dir,
                                   const char* fileroot,
                                   COMMAND_T command,
                                   const char* extension,
                                   BOOLEAN_T overwrite){
  if( num_files_ == 0 ){
    return FALSE;
  }
  
  // allocate array
  *file_array_ptr = (FILE**)mycalloc(num_files_, sizeof(FILE*));
  const char* basename = command_type_to_file_string_ptr(command);

  // determine the target/decoy name component for each file
  string* target_decoy_list = new string[num_files_];
  target_decoy_list[0] = "target";
  if( num_files_ == 2 ){
    target_decoy_list[1] = "decoy";
  }else{
    for(int file_idx = 1; file_idx < num_files_; file_idx++){
      ostringstream name_builder;
      name_builder << "decoy-" << file_idx;
      target_decoy_list[file_idx] = name_builder.str();
    }
  }

  // create each file
  for(int file_idx = 0; file_idx < num_files_; file_idx++ ){
    // concatinate the pieces of the name
    ostringstream name_builder;
    if( fileroot ){
      name_builder << fileroot << "." ;
    }
    name_builder << basename << ".";
    if( !target_decoy_list[file_idx].empty() ){
      name_builder << target_decoy_list[file_idx] << "." ;
    }
    name_builder << extension;
    string filename = name_builder.str();
    
    // open the file (it checks for success)
    (*file_array_ptr)[file_idx] = create_file_in_path(filename.c_str(),
                                                      output_dir,
                                                      overwrite);
  }// next file
  
  delete [] target_decoy_list;
  
  return TRUE;
}

/**
 * \brief A private function for opening a file according to the given
 * arguments.
 *
 * New file is returned via the file_ptr argument.  File is named
 * output-dir/fileroot.comand_name.extension.  Requires that the
 * output-dir already exist and have write permissions.
 * \returns TRUE if the file is created, else FALSE.
 */
BOOLEAN_T OutputFiles::createFile(FILE** file_ptr,
                                  const char* output_dir,
                                  const char* fileroot,
                                  COMMAND_T command,
                                  const char* extension,
                                  BOOLEAN_T overwrite){

  // construct file name
  const char* basename = command_type_to_file_string_ptr(command);

  ostringstream name_builder;
  if( fileroot ){
    name_builder << fileroot << ".";
  }
  name_builder << basename << "." << extension;
  string filename = name_builder.str();

  // open the file
  *file_ptr = create_file_in_path(filename.c_str(),
                                  output_dir,
                                  overwrite);

  if( *file_ptr == NULL ){ return FALSE; }

  return TRUE;
}
/**
 * \brief Write header lines to the .txt and .sqt files.
 */
void OutputFiles::writeHeaders(int num_proteins){

  const char* tag = "target";

  // write headers one file at a time for tab and sqt
  for(int file_idx = 0; file_idx < num_files_; file_idx++){
    if( tab_file_array_ ){
      print_tab_header(tab_file_array_[file_idx]);
    }

    if( sqt_file_array_ ){
      print_sqt_header(sqt_file_array_[file_idx],
                       tag,
                       num_proteins, FALSE); // not post search
    }
    tag = "decoy";
  }
}
/**
 * \brief Write header lines to the optional feature file.
 */
void OutputFiles::writeFeatureHeader(char** feature_names,
                                     int num_names){
  // TODO (BF 27-Apr-10): label first two columns as scan, decoy
  // write feature file header
  if( feature_names && feature_file_ && num_names ){
    fprintf(feature_file_, "%s", feature_names[0]);
    for(int name_idx = 1; name_idx < num_names; name_idx++){
      fprintf(feature_file_, "\t%s", feature_names[name_idx]);
    }
    fprintf(feature_file_, "\n");
  }
}
/**
 * \brief Write the given matches to appropriate output files.  Limit
 * the number of matches per spectrum based on top-match parameter
 * using the ranks from rank_type.  
 */
// TODO: ensure this causes no changes to the match collections by
// making them const
void OutputFiles::writeMatches(
  MATCH_COLLECTION_T*  target_matches, ///< from real peptides
  MATCH_COLLECTION_T** decoy_matches_array,  
                                ///< array of collections from shuffled peptides
  int num_decoy_collections,    ///< num collections in array
  SCORER_TYPE_T rank_type,           ///< use ranks for this type
  SPECTRUM_T* spectrum     ///< given when all matches are to one spec
  ){

  if( target_matches == NULL ){
    return;  // warn?
  }

  // confirm that there are the expected number of decoy collections
  if( num_decoy_collections != num_files_ - 1){
    carp(CARP_FATAL, 
         "WriteMatches was given %d decoy collections but was expecting %d.",
         num_decoy_collections, num_files_ - 1);
  }

  // print to each file type
  printMatchesTab(target_matches, decoy_matches_array, rank_type, spectrum);
  
  printMatchesSqt(target_matches, decoy_matches_array, spectrum);

}

// already confirmed that num_files_ = num decoy collections + 1
void OutputFiles::printMatchesTab(
  MATCH_COLLECTION_T*  target_matches, ///< from real peptides
  MATCH_COLLECTION_T** decoy_matches_array,  
  SCORER_TYPE_T rank_type,
  SPECTRUM_T* spectrum
){

  carp(CARP_DETAILED_DEBUG, "Writing tab delimited results.");

  if( tab_file_array_ == NULL ){
    return;
  }

  // if a spectrum is given, use one print function
  if( spectrum ){
    MATCH_COLLECTION_T* cur_matches = target_matches;

    for(int file_idx = 0; file_idx < num_files_; file_idx++){

      print_match_collection_tab_delimited(tab_file_array_[file_idx],
                                           matches_per_spec_,
                                           cur_matches,
                                           spectrum,
                                           rank_type);

      carp(CARP_DETAILED_DEBUG, "done writing file index %d", file_idx);
      if( decoy_matches_array ){
        cur_matches = decoy_matches_array[file_idx];
      }// else if it is NULL, num_files_ == 1 and loop will exit here
    }

  } else { // use the multi-spectra print function which assumes
           // targets and decoys are merged
    print_matches_multi_spectra(target_matches,
                                tab_file_array_[0],
                                (num_files_ > 1) ? tab_file_array_[1] : NULL);
  }

}

void OutputFiles::printMatchesSqt(
  MATCH_COLLECTION_T*  target_matches, ///< from real peptides
  MATCH_COLLECTION_T** decoy_matches_array,  
                                ///< array of collections from shuffled peptides
  SPECTRUM_T* spectrum
){

  if( sqt_file_array_ == NULL ){
    return;
  }

  MATCH_COLLECTION_T* cur_matches = target_matches;

  for(int file_idx = 0; file_idx < num_files_; file_idx++){

    print_match_collection_sqt(sqt_file_array_[file_idx],
                               matches_per_spec_,
                               cur_matches,
                               spectrum);

    if( decoy_matches_array ){
      cur_matches = decoy_matches_array[file_idx];
    } // else if NULL, num_files_==1 and this is last loop
  }

}

void OutputFiles::writeMatches(
  MATCH_COLLECTION_T*  matches ///< from multiple spectra
){
  print_matches_multi_spectra(matches, 
                              tab_file_array_[0], 
                              NULL);// no decoy file
}

/**
 * \brief Print features from one match to file.
 */
void OutputFiles::writeMatchFeatures(
   MATCH_T* match, ///< match to provide scan num, decoy
   double* features,///< features for this match
   int num_features)///< size of features array
{
  if( feature_file_ == NULL ){ return; }

  // write scan number
  fprintf(feature_file_, "%i\t",
          get_spectrum_first_scan(get_match_spectrum(match)) );

  // decoy or target peptide
  if (get_match_null_peptide(match) == FALSE){
    fprintf(feature_file_, "1\t");
  } else { 
    fprintf(feature_file_, "-1\t");
  };
  
  // print each feature, end in new-line
  for(int feature_idx = 0; feature_idx < num_features; feature_idx++){
    if (feature_idx < num_features - 1){
      fprintf(feature_file_, "%.4f\t", features[feature_idx]);
    } else {
      fprintf(feature_file_, "%.4f\n", features[feature_idx]);
    }
  }

}












/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 2
 * End:
 */
